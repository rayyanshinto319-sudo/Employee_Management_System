from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Employee',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=100)),
                ('department', models.CharField(choices=[
                    ('HR', 'HR'), ('Developer', 'Developer'), ('Manager', 'Manager'),
                    ('Designer', 'Designer'), ('Finance', 'Finance'), ('Marketing', 'Marketing'),
                    ('Sales', 'Sales'), ('IT', 'IT'), ('Operations', 'Operations'),
                ], max_length=50)),
                ('age', models.PositiveIntegerField()),
                ('email', models.EmailField(max_length=254, unique=True)),
                ('phone', models.CharField(max_length=20)),
                ('salary', models.DecimalField(decimal_places=2, max_digits=10)),
                ('address', models.TextField(blank=True)),
                ('profile_image', models.ImageField(blank=True, null=True, upload_to='profile_images/')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={'ordering': ['id']},
        ),
    ]
